import Constants from './constants.js';

/**
 * Handle setting and fetching all settings in the module
 */
export default class Settings {
  // Settings keys
  static CHAT_MESSAGE_PERMISSION = 'chatMessagePermission';
  static APP_CONTROLS_PERMISSION = 'controlsPermission';
  static ALLOW_PLAYER_CUSTOM_EFFECTS = 'allowPlayerCustomEffects';
  static INTEGRATE_WITH_ATE = 'integrateWithAtl';
  static INTEGRATE_WITH_TOKEN_MAGIC = 'integrateWithTokenMagic';
  static MODIFY_STATUS_EFFECTS = 'modifyStatusEffects';
  static PRIORITIZE_TARGETS = 'prioritizeTargets';
  static REMOVE_CONTROLS_PERMISSION = 'removeControlsPermission';
  static SHOW_CHAT_MESSAGE_EFFECT_DESCRIPTION = 'chatMessageEffectDescription';
  static SHOW_NESTED_EFFECTS = 'showNestedEffects';

  static FAVORITE_EFFECT_NAMES = 'favoriteEffectNames';
  static STATUS_EFFECT_NAMES = 'statusEffectNames';
  static EXPANDED_FOLDERS = 'expandedFolders';
  static CUSTOM_EFFECTS_ITEM_ID = 'customEffectsItemId';

  /**
   * Register all the settings for the module
   */
  registerSettings() {
    const userRoles = {};
    userRoles[CONST.USER_ROLES.PLAYER] = 'Игрок';
    userRoles[CONST.USER_ROLES.TRUSTED] = 'Доверенный';
    userRoles[CONST.USER_ROLES.ASSISTANT] = 'Ассистент GM';
    userRoles[CONST.USER_ROLES.GAMEMASTER] = 'Мастер';
    userRoles[5] = 'None';

    game.settings.register(
      Constants.MODULE_ID,
      Settings.CHAT_MESSAGE_PERMISSION,
      {
        name: 'Разрешение на сообщения в чате',
        hint: 'Определяет минимальный уровень разрешения для просмотра сообщений чата при наложении, удалении или истечении срока действия эффектов. Если установить значение Нет, сообщения чата никогда не будут отображаться.',
        scope: 'world',
        config: true,
        default: CONST.USER_ROLES.GAMEMASTER,
        choices: userRoles,
        type: String,
      }
    );

    game.settings.register(
      Constants.MODULE_ID,
      Settings.APP_CONTROLS_PERMISSION,
      {
        name: 'Разрешение на управление приложением',
        hint: 'Определяет минимальный уровень разрешения для просмотра и применения Удобных Эффектов в приложении через кнопку на элементах управления токеном. Установка значения Нет полностью отключает кнопку.',
        scope: 'world',
        config: true,
        default: CONST.USER_ROLES.GAMEMASTER,
        choices: userRoles,
        type: String,
        requiresReload: true,
      }
    );

    game.settings.register(
      Constants.MODULE_ID,
      Settings.REMOVE_CONTROLS_PERMISSION,
      {
        name: 'Удалить разрешение на управление',
        hint: 'Определяет минимальный уровень разрешения для удаления Удобных Эффектов с помощью кнопки на элементах управления токеном. Если установить значение Нет, кнопка будет полностью отключена.',
        scope: 'world',
        config: true,
        default: CONST.USER_ROLES.GAMEMASTER,
        choices: userRoles,
        type: String,
        requiresReload: true,
      }
    );

    game.settings.register(
      Constants.MODULE_ID,
      Settings.ALLOW_PLAYER_CUSTOM_EFFECTS,
      {
        name: 'Разрешить игроку пользовательские эффекты',
        hint: 'Если включено, игрокам будет разрешено создавать, дублировать, редактировать и удалять все пользовательские эффекты.',
        scope: 'world',
        config: true,
        default: false,
        type: Boolean,
        onChange: async (value) => {
          const customEffectsItem = await this._findCustomEffectsItem();

          if (!customEffectsItem) return;

          let newOwnership = duplicate(customEffectsItem.ownership);
          newOwnership.default = value ? 3 : 0;
          await customEffectsItem.update({ ownership: newOwnership });
        },
      }
    );

    game.settings.register(Constants.MODULE_ID, Settings.INTEGRATE_WITH_ATE, {
      name: 'Интеграция с ATE',
      hint: 'Если включено, определенные эффекты будут также изменять свет, излучаемый токенами, или размер токенов через Active Token Effects.',
      scope: 'world',
      config: true,
      default: true,
      type: Boolean,
    });

    game.settings.register(
      Constants.MODULE_ID,
      Settings.INTEGRATE_WITH_TOKEN_MAGIC,
      {
        name: 'Интеграция с Token Magic',
        hint: 'Если включено, некоторые эффекты также будут применять фильтр магии токенов через Token Magic.',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
      }
    );

    game.settings.register(
      Constants.MODULE_ID,
      Settings.MODIFY_STATUS_EFFECTS,
      {
        name: 'Изменение эффектов статуса',
        hint: 'Так будут изменены эффекты состояния на токене. Их замена означает, что все остальные эффекты статусов будут удалены в пользу условий, предоставляемых Удобными эффектами. Их добавление означает, что они будут добавлены в конец существующих эффектов статусов. Требуется перезагрузка Foundry при изменении.',
        scope: 'world',
        config: true,
        default: 'none',
        choices: {
          none: 'Нет',
          replace: 'Заменить',
          add: 'Добавить',
        },
        type: String,
        requiresReload: true,
      }
    );

    game.settings.register(Constants.MODULE_ID, Settings.PRIORITIZE_TARGETS, {
      name: 'Определите приоритетность целей',
      hint: 'Если включено, эффекты будут применяться ко всем целевым токенам, а не к выделенным токенам.',
      scope: 'client',
      config: true,
      default: false,
      type: Boolean,
    });

    game.settings.register(
      Constants.MODULE_ID,
      Settings.SHOW_CHAT_MESSAGE_EFFECT_DESCRIPTION,
      {
        name: 'Описание эффекта "Показать сообщение чата',
        hint: 'Когда описания эффектов отображаются в сообщениях чата.',
        scope: 'world',
        config: true,
        default: true,
        default: 'onAddOrRemove',
        choices: {
          onAddOrRemove: 'При добавлении или удалении',
          onAddOnly: 'Только при добавлении',
          never: 'Никогда',
        },
        type: String,
      }
    );

    game.settings.register(Constants.MODULE_ID, Settings.SHOW_NESTED_EFFECTS, {
      name: 'Показать вложенные эффекты',
      hint: 'Если включено, вложенные эффекты будут отображаться в приложении.',
      scope: 'client',
      config: true,
      default: false,
      type: Boolean,
    });

    game.settings.register(
      Constants.MODULE_ID,
      Settings.FAVORITE_EFFECT_NAMES,
      {
        name: 'Favorite Effect Names',
        scope: 'client',
        config: false,
        default: '',
        type: Array,
      }
    );

    game.settings.register(Constants.MODULE_ID, Settings.STATUS_EFFECT_NAMES, {
      name: 'Status Effect Names',
      scope: 'world',
      config: false,
      default: this._defaultStatusEffectNames,
      type: Array,
    });

    game.settings.register(Constants.MODULE_ID, Settings.EXPANDED_FOLDERS, {
      name: 'Expanded Folders',
      scope: 'client',
      config: false,
      default: 'Favorites',
      type: Array,
    });

    game.settings.register(
      Constants.MODULE_ID,
      Settings.CUSTOM_EFFECTS_ITEM_ID,
      {
        name: 'Custom Effects Item ID',
        scope: 'world',
        config: false,
        default: '',
        type: String,
      }
    );
  }

  get _defaultStatusEffectNames() {
    return [
      'Слепота',
      'Обворожение',
      'Концентрация',
      'Смерть',
      'Глухота',
      'Утомление 1',
      'Утомление 2',
      'Утомление 3',
      'Утомление 4',
      'Утомление 5',
      'Испуг',
      'Обездвиженность',
      'Потеря сознания',
      'Невидимость',
      'Паралич',
      'Окаменение',
      'Отравление',
      'Распластанность',
      'Обездвиженность',
      'Шок',
      'Выход из строя',
    ];
  }

  /**
   * Returns the game setting for chat message permission
   *
   * @returns {number} a number representing the chosen role
   */
  get chatMessagePermission() {
    return parseInt(
      game.settings.get(Constants.MODULE_ID, Settings.CHAT_MESSAGE_PERMISSION)
    );
  }

  /**
   * Returns the game setting for app controls permission
   *
   * @returns {number} a number representing the chosen role
   */
  get appControlsPermission() {
    return parseInt(
      game.settings.get(Constants.MODULE_ID, Settings.APP_CONTROLS_PERMISSION)
    );
  }

  /**
   * Returns the game setting for allowing players to manipulate custom effects.
   *
   * @returns {boolean} true if players can manipulate custom effects
   */
  get allowPlayerCustomEffects() {
    return game.settings.get(
      Constants.MODULE_ID,
      Settings.ALLOW_PLAYER_CUSTOM_EFFECTS
    );
  }

  /**
   * Returns the game setting for integrating with ATE
   *
   * @returns {boolean} true if integration with ATE is enabled
   */
  get integrateWithAte() {
    return game.settings.get(Constants.MODULE_ID, Settings.INTEGRATE_WITH_ATE);
  }

  /**
   * Returns the game setting for integrating with Token Magic
   *
   * @returns {boolean} true if integration with Token Magic is enabled
   */
  get integrateWithTokenMagic() {
    return game.settings.get(
      Constants.MODULE_ID,
      Settings.INTEGRATE_WITH_TOKEN_MAGIC
    );
  }

  /**
   * Returns the game setting for status effect type
   *
   * @returns {string} a string representing the chosen status effect type
   */
  get modifyStatusEffects() {
    return game.settings.get(
      Constants.MODULE_ID,
      Settings.MODIFY_STATUS_EFFECTS
    );
  }

  /**
   * Returns the game setting for prioritizing targets
   *
   * @returns {boolean} true if targets should take first priority
   */
  get prioritizeTargets() {
    return game.settings.get(Constants.MODULE_ID, Settings.PRIORITIZE_TARGETS);
  }

  /**
   * Returns the game setting for remove controls permission
   *
   * @returns {number} a number representing the chosen role
   */
  get removeControlsPermission() {
    return parseInt(
      game.settings.get(
        Constants.MODULE_ID,
        Settings.REMOVE_CONTROLS_PERMISSION
      )
    );
  }

  /**
   * Returns the game setting for the chat effect description
   *
   * @returns {string} a string representing the chosen chat effect description
   */
  get showChatMessageEffectDescription() {
    return game.settings.get(
      Constants.MODULE_ID,
      Settings.SHOW_CHAT_MESSAGE_EFFECT_DESCRIPTION
    );
  }

  /**
   * Returns the game setting for showing nested effects
   *
   * @returns {boolean} true if nested effects should be shown
   */
  get showNestedEffects() {
    return game.settings.get(Constants.MODULE_ID, Settings.SHOW_NESTED_EFFECTS);
  }

  /**
   * Returns the game setting for the favorite effect names
   *
   * @returns {String[]} the names of all the favorite effects
   */
  get favoriteEffectNames() {
    return game.settings.get(
      Constants.MODULE_ID,
      Settings.FAVORITE_EFFECT_NAMES
    );
  }

  /**
   * Adds a given effect name to the saved favorite settings
   *
   * @param {string} name - the name of the effect to add to favorites
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async addFavoriteEffect(name) {
    let favoriteEffectsArray = this.favoriteEffectNames;
    favoriteEffectsArray.push(name);

    favoriteEffectsArray = [...new Set(favoriteEffectsArray)]; // remove duplicates

    return game.settings.set(
      Constants.MODULE_ID,
      Settings.FAVORITE_EFFECT_NAMES,
      favoriteEffectsArray
    );
  }

  /**
   * Removes a given effect name from the saved favorite settings
   *
   * @param {string} name - the name of the effect to remove from favorites
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async removeFavoriteEffect(name) {
    let favoriteEffectsArray = this.favoriteEffectNames.filter(
      (favoriteEffect) => favoriteEffect !== name
    );
    return game.settings.set(
      Constants.MODULE_ID,
      Settings.FAVORITE_EFFECT_NAMES,
      favoriteEffectsArray
    );
  }

  /**
   * Checks if the given effect name is favorited
   *
   * @param {string} name - the effect name to search for
   * @returns {boolean} true if the effect is favorited, false otherwise
   */
  isFavoritedEffect(name) {
    return this.favoriteEffectNames.includes(name);
  }

  /**
   * Returns the game setting for the status effect names
   *
   * @returns {String[]} the names of all the status effects
   */
  get statusEffectNames() {
    return game.settings.get(Constants.MODULE_ID, Settings.STATUS_EFFECT_NAMES);
  }

  /**
   * Adds a given effect name to the saved status effect settings
   *
   * @param {string} name - the name of the effect to add to status effects
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async addStatusEffect(name) {
    let statusEffectsArray = this.statusEffectNames;
    statusEffectsArray.push(name);

    statusEffectsArray = [...new Set(statusEffectsArray)]; // remove duplicates

    return game.settings.set(
      Constants.MODULE_ID,
      Settings.STATUS_EFFECT_NAMES,
      statusEffectsArray
    );
  }

  /**
   * Removes a given effect name from the saved status effect settings
   *
   * @param {string} name - the name of the effect to remove from status effects
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async removeStatusEffect(name) {
    let statusEffectsArray = this.statusEffectNames.filter(
      (statusEffect) => statusEffect !== name
    );
    return game.settings.set(
      Constants.MODULE_ID,
      Settings.STATUS_EFFECT_NAMES,
      statusEffectsArray
    );
  }

  /**
   * Reset status effects back to the original defaults
   *
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async resetStatusEffects() {
    return game.settings.set(
      Constants.MODULE_ID,
      Settings.STATUS_EFFECT_NAMES,
      this._defaultStatusEffectNames
    );
  }

  /**
   * Checks if the given effect name is a status effect
   *
   * @param {string} name - the effect name to search for
   * @returns {boolean} true if the effect is a status effect, false otherwise
   */
  isStatusEffect(name) {
    return this.statusEffectNames.includes(name);
  }

  /**
   * Returns the game setting for the saved expanded folder names
   *
   * @returns {String[]} the IDs of all of the saved expanded folders
   */
  get expandedFolders() {
    return game.settings.get(Constants.MODULE_ID, Settings.EXPANDED_FOLDERS);
  }

  /**
   * Adds a given folder ID to the saved expanded folders
   *
   * @param {string} id - the ID of the folder to add to the saved expanded folders
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async addExpandedFolder(id) {
    let expandedFolderArray = this.expandedFolders;
    expandedFolderArray.push(id);

    expandedFolderArray = [...new Set(expandedFolderArray)]; // remove duplicates

    return game.settings.set(
      Constants.MODULE_ID,
      Settings.EXPANDED_FOLDERS,
      expandedFolderArray
    );
  }

  /**
   * Removes a given folder name from the saved expanded folders
   *
   * @param {string} id - the ID of the folder to remove from the saved expanded folders
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async removeExpandedFolder(id) {
    let expandedFolderArray = this.expandedFolders.filter(
      (expandedFolder) => expandedFolder !== id
    );
    return game.settings.set(
      Constants.MODULE_ID,
      Settings.EXPANDED_FOLDERS,
      expandedFolderArray
    );
  }

  /**
   * Removes all saved expanded folders
   *
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async clearExpandedFolders() {
    return game.settings.set(
      Constants.MODULE_ID,
      Settings.EXPANDED_FOLDERS,
      []
    );
  }

  /**
   * Checks if the given folder name is expanded
   *
   * @param {string} id - the folder ID to search for
   * @returns {boolean} true if the folder is in the saved expanded folders, false otherwise
   */
   isFolderExpanded(id) {
    return this.expandedFolders.includes(id);
  }

  /**
   * Returns the game setting for the custom effects item ID
   *
   * @returns {string} the ID of the custom effects item
   */
  get customEffectsItemId() {
    return game.settings.get(
      Constants.MODULE_ID,
      Settings.CUSTOM_EFFECTS_ITEM_ID
    );
  }

  /**
   * Sets the custom effects item ID
   *
   * @param {string} id - the ID of the custom effects item
   * @returns {Promise} a promise that resolves when the settings update is complete
   */
  async setCustomEffectsItemId(id) {
    return game.settings.set(
      Constants.MODULE_ID,
      Settings.CUSTOM_EFFECTS_ITEM_ID,
      id
    );
  }

  _findCustomEffectsItem() {
    return game.items.get(this.customEffectsItemId);
  }
}
